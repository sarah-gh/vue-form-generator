<template>
    <div>
        <template v-if="item.mode === 'select'">
            <label>{{item.label}}</label>
            <select v-model="item.value" v-bind="item.options">
                <option disabled value="">Please select one</option>
                <option v-for="x in item.options" :value="x"  :key="x">{{ x }}</option>
            </select>
        </template>
        <template v-else-if="item.mode === 'auto-complete'">
            <label>{{item.label}}</label>
            <select v-model="item.value" v-bind="item.options">
                <option disabled value="">Please select one</option>
                <option v-for="x in item.options" :value="x"  :key="x">{{ x }}</option>
            </select>
        </template>
        <template v-else-if="item.mode === 'checkbox'">
            <label>{{item.label}}</label>
            <input type="checkbox" id="jack" value="Jack" v-model="item.value">
            <label for="mike">Mike</label>
        </template>
        <template v-else-if="item.mode === 'checkbox-group'">
            <p v-if="item.label">{{ item.label }}</p>
        </template>
        <template v-else-if="item.mode === 'radio-group'">
            <p v-if="item.label">{{ item.label }}</p>
        </template>
        <template v-else-if="item.mode === 'textarea'">
            <textarea v-model="item.value" placeholder="add multiple lines"></textarea>
        </template>
        <template v-else-if="item.mode === 'date-picker'"> 
            <label>{{item.label}}</label>
            <input v-model="item.value" placeholder="date-picker">
        </template>
        <template v-else-if="item.mode === 'label'">
            <span>{{ item.value }}</span>
        </template>
        <template v-else-if="item.mode === 'money'"> 
            <label>{{item.label}}</label>
            <input v-model="item.value" placeholder="money">
        </template>
        <template v-else-if="!item.mode || item.mode === 'text'"> 
            <template v-if="item.options && item.options.covertToNumber">
                <label>{{item.label}}</label>
                <input v-model="item.value" placeholder="text">
            </template>
            <template v-else>
                <label>{{item.label}}</label>
                <input v-model="item.value" placeholder="text">
            </template>
        </template>
    </div>
</template>

<script>
  export default {
    props: {
      item: {
        required: true,
        type: Object,
      },
    },
  };
</script>

<style>

</style>
